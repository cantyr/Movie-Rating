/* 
 * File:   main.cpp
 * Author: owner
 *
 * Created on September 30, 2015, 4:25 PM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#include <string>
#include <sstream>

using namespace std;

void verify( int );

/*
 * 
 */
int main() {

    int G = 1;
    int PG = 2;
    int PG13 = 3;
    int R = 4;
    cout << "Ratings Menu:" << endl;
    cout << G << ". Rated G" << endl;
    cout << PG << ". Rated PG" << endl;
    cout << PG13 << ". Rated PG-13" << endl;
    cout << R << ". Rated R" << endl;
    cout << " " << endl;
    
    int rating;
    cout << "Please select a rating: " << endl;
    cin >> rating;
    
    verify( rating );
            
  
    
    return 0;
}

void verify( int r )
{
    if ( r == 1 )
    {
        cout << " " << endl;
        cout << "You may see the movie!";
    }
    else if ( r == 2 )
    {
        int age;
        string answer = "";
        cout << "How old are you? " << endl;
        cin >> age;
        if( age >= 10 )
        {
            cout << " " << endl;
            cout << "You may see the movie!" << endl;
        }
        else if( age < 10 )
        {
            cout << "Do you have a parent or guardian with you? " << endl;
            cin >> answer;
        }    
            
            if( answer.size() == 2 )
            {
                cout << " " << endl;
                cout << "You may not see the movie!" << endl;
            }
            else if( answer.size() == 3 )
            {
                cout << " " << endl;
                cout << "You may see the movie!";
            }
    }   
    else if ( r == 3 )
    {
        int age;
        string answer = "";
        cout << "How old are you? " << endl;
        cin >> age;
        if( age >= 13 )
        {
            cout << " " << endl;
            cout << "You may see the movie!";
        }
        else if( age < 13 )
        {
            cout << "Do you have a parent or guardian with you? " << endl;
            cin >> answer;
        }    
            
            if( answer.size() == 2 )
            {
                cout << " " << endl;
                cout << "You may not see the movie!";
            }
            else if( answer.size() == 3 )
            {
                cout << " " << endl;
                cout << "You may see the movie!";
            }
    }   
    else if ( r == 4 )
    {
        int age;
        string answer = "";
        cout << "How old are you? " << endl;
        cin >> age;
        if( age >= 17 )
        {
            cout << " " << endl;
            cout << "You may see the movie!";
        }
        else if( age < 17 )
        {
            cout << "Do you have a parent or guardian with you? " << endl;
            cin >> answer;
        }    
            
            if( answer.size() == 2 )
            {
                cout << " " << endl;
                cout << "You may not see the movie!";
            }
            else if( answer.size() == 3 )
            {
                cout << " " << endl;
                cout << "You may see the movie!";
            }
    }   
}